# /// script
# requires-python = ">=3.10"
# dependencies = []
# ///
"""
Export football analysis data to data.js for the web frontend.

Reads all CSV files, builds both wins (2+ goals) and corners (10+)
datasets, then writes `data.js` which assigns a global FOOTYDATA variable.
This avoids CORS issues with file:// protocol.

Usage:
    uv run export_data.py
"""

from __future__ import annotations

import csv
import json
import os
import sys
from pathlib import Path
from collections import defaultdict

# Ensure UTF-8 output on Windows
if sys.platform == "win32":
    os.environ.setdefault("PYTHONUTF8", "1")
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# ── CSV files to process (filename -> pretty league name) ─────────────────────
LEAGUE_FILES: dict[str, str] = {
    "Premier League_2026-2027.csv": "Premier League 26/27",
    "Premier League_2025-2026.csv": "Premier League 25/26",
    "Premier League_2024-2025.csv": "Premier League 24/25",
    "Premier League_2023-2024.csv": "Premier League 23/24",
    "Premier League_2022-2023.csv": "Premier League 22/23",
    "Championship_2026-2027.csv": "Championship 26/27",
    "Championship_2025-2026.csv": "Championship 25/26",
    "Championship_2024-2025.csv": "Championship 24/25",
    "Championship_2023-2024.csv": "Championship 23/24",
    "Championship_2022-2023.csv": "Championship 22/23",
    "League One_2026-2027.csv": "League One 26/27",
    "League One_2025-2026.csv": "League One 25/26",
    "League One_2024-2025.csv": "League One 24/25",
    "League One_2023-2024.csv": "League One 23/24",
    "League One_2022-2023.csv": "League One 22/23",
    "League Two_2026-2027.csv": "League Two 26/27",
    "League Two_2025-2026.csv": "League Two 25/26",
    "League Two_2024-2025.csv": "League Two 24/25",
    "League Two_2023-2024.csv": "League Two 23/24",
    "League Two_2022-2023.csv": "League Two 22/23",
    "National League_2026-2027.csv": "National League 26/27",
    "National League_2025-2026.csv": "National League 25/26",
    "National League_2024-2025.csv": "National League 24/25",
    "National League_2023-2024.csv": "National League 23/24",
    "National League_2022-2023.csv": "National League 22/23",
    "Scottish Premiership_2026-2027.csv": "Scottish Premiership 26/27",
    "Scottish Premiership_2025-2026.csv": "Scottish Premiership 25/26",
    "Scottish Premiership_2024-2025.csv": "Scottish Premiership 24/25",
    "Scottish Premiership_2023-2024.csv": "Scottish Premiership 23/24",
    "Scottish Premiership_2022-2023.csv": "Scottish Premiership 22/23",
    "Scottish League One_2026-2027.csv": "Scottish League One 26/27",
    "Scottish League One_2025-2026.csv": "Scottish League One 25/26",
    "Scottish League One_2024-2025.csv": "Scottish League One 24/25",
    "Scottish League One_2023-2024.csv": "Scottish League One 23/24",
    "Scottish League One_2022-2023.csv": "Scottish League One 22/23",
    "La Liga_2026-2027.csv": "La Liga 26/27",
    "La Liga_2025-2026.csv": "La Liga 25/26",
    "La Liga_2024-2025.csv": "La Liga 24/25",
    "La Liga_2023-2024.csv": "La Liga 23/24",
    "La Liga_2022-2023.csv": "La Liga 22/23",
    "La Liga 2_2026-2027.csv": "La Liga 2 26/27",
    "La Liga 2_2025-2026.csv": "La Liga 2 25/26",
    "La Liga 2_2024-2025.csv": "La Liga 2 24/25",
    "La Liga 2_2023-2024.csv": "La Liga 2 23/24",
    "La Liga 2_2022-2023.csv": "La Liga 2 22/23",
    "Bundesliga_2026-2027.csv": "Bundesliga 26/27",
    "Bundesliga_2025-2026.csv": "Bundesliga 25/26",
    "Bundesliga_2024-2025.csv": "Bundesliga 24/25",
    "Bundesliga_2023-2024.csv": "Bundesliga 23/24",
    "Bundesliga_2022-2023.csv": "Bundesliga 22/23",
    "Bundesliga 2_2026-2027.csv": "Bundesliga 2 26/27",
    "Bundesliga 2_2025-2026.csv": "Bundesliga 2 25/26",
    "Bundesliga 2_2024-2025.csv": "Bundesliga 2 24/25",
    "Bundesliga 2_2023-2024.csv": "Bundesliga 2 23/24",
    "Bundesliga 2_2022-2023.csv": "Bundesliga 2 22/23",
    "Serie A_2026-2027.csv": "Serie A 26/27",
    "Serie A_2025-2026.csv": "Serie A 25/26",
    "Serie A_2024-2025.csv": "Serie A 24/25",
    "Serie A_2023-2024.csv": "Serie A 23/24",
    "Serie A_2022-2023.csv": "Serie A 22/23",
    "Serie B_2026-2027.csv": "Serie B 26/27",
    "Serie B_2025-2026.csv": "Serie B 25/26",
    "Serie B_2024-2025.csv": "Serie B 24/25",
    "Serie B_2023-2024.csv": "Serie B 23/24",
    "Serie B_2022-2023.csv": "Serie B 22/23",
    "League of Ireland Premier Division_2012-2026.csv": "League of Ireland Premier Division 12/26",
    "Ligue 1_2026-2027.csv": "Ligue 1 26/27",
    "Ligue 1_2025-2026.csv": "Ligue 1 25/26",
    "Ligue 1_2024-2025.csv": "Ligue 1 24/25",
    "Ligue 1_2023-2024.csv": "Ligue 1 23/24",
    "Ligue 1_2022-2023.csv": "Ligue 1 22/23",
    "Ligue 2_2026-2027.csv": "Ligue 2 26/27",
    "Ligue 2_2025-2026.csv": "Ligue 2 25/26",
    "Ligue 2_2024-2025.csv": "Ligue 2 24/25",
    "Ligue 2_2023-2024.csv": "Ligue 2 23/24",
    "Ligue 2_2022-2023.csv": "Ligue 2 22/23",
    "Eredivisie_2026-2027.csv": "Eredivisie 26/27",
    "Eredivisie_2025-2026.csv": "Eredivisie 25/26",
    "Eredivisie_2024-2025.csv": "Eredivisie 24/25",
    "Eredivisie_2023-2024.csv": "Eredivisie 23/24",
    "Eredivisie_2022-2023.csv": "Eredivisie 22/23",
    "Poland Ekstraklasa_2012-2027.csv": "Poland Ekstraklasa 12/27",
    "Primeira Liga_2026-2027.csv": "Primeira Liga 26/27",
    "Primeira Liga_2025-2026.csv": "Primeira Liga 25/26",
    "Primeira Liga_2024-2025.csv": "Primeira Liga 24/25",
    "Primeira Liga_2023-2024.csv": "Primeira Liga 23/24",
    "Primeira Liga_2022-2023.csv": "Primeira Liga 22/23",
    "Belgium First Division A_2026-2027.csv": "Belgium First Division A 26/27",
    "Belgium First Division A_2025-2026.csv": "Belgium First Division A 25/26",
    "Belgium First Division A_2024-2025.csv": "Belgium First Division A 24/25",
    "Belgium First Division A_2023-2024.csv": "Belgium First Division A 23/24",
    "Belgium First Division A_2022-2023.csv": "Belgium First Division A 22/23",
    "Super Lig_2026-2027.csv": "Super Lig 26/27",
    "Super Lig_2025-2026.csv": "Super Lig 25/26",
    "Super Lig_2024-2025.csv": "Super Lig 24/25",
    "Super Lig_2023-2024.csv": "Super Lig 23/24",
    "Super Lig_2022-2023.csv": "Super Lig 22/23",
    "Super League Greece_2026-2027.csv": "Super League Greece 26/27",
    "Super League Greece_2025-2026.csv": "Super League Greece 25/26",
    "Super League Greece_2024-2025.csv": "Super League Greece 24/25",
    "Super League Greece_2023-2024.csv": "Super League Greece 23/24",
    "Super League Greece_2022-2023.csv": "Super League Greece 22/23",
}

# ── Helpers ───────────────────────────────────────────────────────────────────


def read_csv(filepath: Path) -> list[dict[str, str]]:
    with open(filepath, encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        rows = []
        for row in reader:
            cleaned = {k.strip(): v.strip() for k, v in row.items() if k}
            rows.append(cleaned)
        return rows


def safe_int(val: str) -> int:
    try:
        return int(val)
    except (ValueError, TypeError):
        return 0


def match_to_compact(row: dict[str, str]) -> list:
    """Return a compact array instead of object to save space.
    Index: 0=date, 1=home, 2=away, 3=fthg, 4=ftag, 5=ftr,
           6=hthg, 7=htag, 8=hc, 9=ac, 10=tc,
           11=win2plus_home, 12=win2plus_away, 13=corners10plus, 14=league_idx
    """
    hc = safe_int(row.get("HC", "0"))
    ac = safe_int(row.get("AC", "0"))
    fthg = safe_int(row.get("FTHG", "0"))
    ftag = safe_int(row.get("FTAG", "0"))
    ftr = row.get("FTR", "").strip()

    return [
        row.get("Date", ""),              # 0
        row.get("HomeTeam", "").strip(),   # 1
        row.get("AwayTeam", "").strip(),   # 2
        fthg,                              # 3
        ftag,                              # 4
        ftr,                               # 5
        safe_int(row.get("HTHG", "0")),    # 6
        safe_int(row.get("HTAG", "0")),    # 7
        hc,                                # 8
        ac,                                # 9
        hc + ac,                           # 10
        1 if (ftr == "H" and fthg >= 2) else 0,  # 11 win2plus_home
        1 if (ftr == "A" and ftag >= 2) else 0,  # 12 win2plus_away
        1 if (hc + ac) >= 10 else 0,             # 13 corners10plus
        # 14 = league index, added later
    ]


def build_all_data(base_dir: Path) -> dict:
    leagues_order = []
    all_matches = []
    seen_leagues = {}

    for filename, league_name in LEAGUE_FILES.items():
        filepath = base_dir / filename
        if not filepath.exists():
            continue

        if league_name not in seen_leagues:
            seen_leagues[league_name] = len(leagues_order)
            leagues_order.append(league_name)

        lg_idx = seen_leagues[league_name]
        rows = read_csv(filepath)
        for row in rows:
            m = match_to_compact(row)
            if not m[1] or not m[2]:
                continue
            m.append(lg_idx)  # index 14 = league index
            all_matches.append(m)

    # Collect unique teams and encode team names as integer indices to compress payload
    all_teams = sorted({m[1] for m in all_matches} | {m[2] for m in all_matches})
    team_to_idx = {name: idx for idx, name in enumerate(all_teams)}

    for m in all_matches:
        m[1] = team_to_idx[m[1]]
        m[2] = team_to_idx[m[2]]

    return {
        "l": leagues_order,    # leagues
        "t": all_teams,        # teams
        "m": all_matches,      # matches (compact arrays with dictionary-encoded teams)
    }


def main() -> None:
    base_dir = Path(__file__).resolve().parent
    data = build_all_data(base_dir)

    out_path = base_dir / "data.js"
    json_str = json.dumps(data, ensure_ascii=False, separators=(',', ':'))

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(f"var FOOTYDATA = {json_str};\n")

    n = len(data["m"])
    nl = len(data["l"])
    nt = len(data["t"])
    sz = out_path.stat().st_size / 1024
    print(f"Exported {n:,} matches | {nl} leagues | {nt} teams | {sz:.0f} KB -> {out_path}")


if __name__ == "__main__":
    main()
